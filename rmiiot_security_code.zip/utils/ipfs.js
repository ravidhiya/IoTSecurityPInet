const { create } = require('ipfs-http-client');
function makeClient(ipfsUrl) {
  const url = ipfsUrl || 'http://127.0.0.1:5001';
  return create({ url });
}
async function uploadJSON(client, jsonObj) {
  const { cid } = await client.add(JSON.stringify(jsonObj));
  return cid.toString();
}
module.exports = { makeClient, uploadJSON };
