require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { generateKey, encrypt } = require('../utils/crypto');
const { makeClient, uploadJSON } = require('../utils/ipfs');
const app = express();
app.use(bodyParser.json({ limit: '2mb' }));

const KEY_STORE = {};
const ipfs = makeClient(process.env.IPFS_URL);

async function recordHashToFabric(recordId, ipfsHash, owner, accessList) {
  console.log('[MOCK FABRIC] Recording:', { recordId, ipfsHash, owner, accessList });
  return { txId: 'MOCK_TX_' + Math.random().toString(36).substring(2, 10) };
}

app.post('/register', async (req, res) => {
  const { deviceId } = req.body;
  if (!deviceId) return res.status(400).json({ error: 'deviceId required' });
  const key = generateKey();
  KEY_STORE[deviceId] = key.toString('base64');
  res.json({ deviceId, key: KEY_STORE[deviceId] });
});

app.post('/ingest', async (req, res) => {
  try {
    const { deviceId, payload } = req.body;
    if (!deviceId || !payload) return res.status(400).json({ error: 'deviceId and payload required' });
    const keyB64 = KEY_STORE[deviceId];
    if (!keyB64) return res.status(400).json({ error: 'unknown deviceId; register first' });
    const key = Buffer.from(keyB64, 'base64');
    const enc = encrypt(JSON.stringify(payload), key);
    const ipfsHash = await uploadJSON(ipfs, { encrypted: enc, meta: { deviceId, timestamp: new Date().toISOString() } });
    const recordId = 'rec_' + Date.now();
    const owner = 'hospitalA';
    const accessList = ['hospitalA'];
    const fabricResp = await recordHashToFabric(recordId, ipfsHash, owner, accessList);
    res.json({ recordId, ipfsHash, fabricTx: fabricResp });
  } catch (err) {
    res.status(500).json({ error: 'server error', detail: err.message });
  }
});

const PORT = process.env.PORT || 3314;
app.listen(PORT, () => console.log(`RMIIoT Security Server listening on ${PORT}`));
