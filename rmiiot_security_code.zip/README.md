# RMIIoT Security Source Code (Example)
This project demonstrates a simplified RMIIoT security architecture with Node.js, IPFS, and Hyperledger Fabric (mocked).
See code files for details. Run instructions provided in comments.
