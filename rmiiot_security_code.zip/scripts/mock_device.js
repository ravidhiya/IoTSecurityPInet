const axios = require('axios');
const SERVER = process.env.SERVER_URL || 'http://localhost:3314';
async function run() {
  const deviceId = 'dev_' + Math.floor(Math.random() * 10000);
  const reg = await axios.post(SERVER + '/register', { deviceId });
  console.log('Registered device, got key:', reg.data.key.substring(0, 12) + '...');
  const payload = { hr: Math.round(60 + Math.random() * 40), spo2: Math.round(94 + Math.random() * 6), temp: (36 + Math.random() * 2).toFixed(2), bp_sys: Math.round(100 + Math.random() * 30) };
  const ingest = await axios.post(SERVER + '/ingest', { deviceId, payload });
  console.log('Ingest response:', ingest.data);
}
run();
