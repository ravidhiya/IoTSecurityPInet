'use strict';
const { Contract } = require('fabric-contract-api');

class MedicalContract extends Contract {
  async initLedger(ctx) { return; }
  async storeRecord(ctx, recordId, ipfsHash, owner, accessListJson) {
    const record = { recordId, ipfsHash, owner, accessList: JSON.parse(accessListJson), timestamp: new Date().toISOString() };
    await ctx.stub.putState(recordId, Buffer.from(JSON.stringify(record)));
    return JSON.stringify(record);
  }
  async readRecord(ctx, recordId) {
    const data = await ctx.stub.getState(recordId);
    if (!data || data.length === 0) throw new Error(`Record ${recordId} does not exist`);
    return data.toString();
  }
  async grantAccess(ctx, recordId, entity) {
    const data = await this.readRecord(ctx, recordId);
    const record = JSON.parse(data);
    if (!record.accessList.includes(entity)) record.accessList.push(entity);
    await ctx.stub.putState(recordId, Buffer.from(JSON.stringify(record)));
    return JSON.stringify(record);
  }
  async revokeAccess(ctx, recordId, entity) {
    const data = await this.readRecord(ctx, recordId);
    const record = JSON.parse(data);
    record.accessList = record.accessList.filter(e => e !== entity);
    await ctx.stub.putState(recordId, Buffer.from(JSON.stringify(record)));
    return JSON.stringify(record);
  }
}
module.exports = MedicalContract;
